# DecepticNNUE — Offline Android MVP

A local-first Flutter chess prototype with legal move validation, local rating persistence, selectable bot difficulty, and no online services.

## What is implemented in this starter
- Interactive chessboard with tap-to-select and tap-to-move.
- Legal moves handled by the `chess` Dart package.
- Local Elo-like rating and W/D/L record saved with `shared_preferences`.
- Bot level selector and a deliberately simple adaptive move-selection prototype.
- No account, backend, analytics, or network gameplay.

## Important limitation
The bot is **not Stockfish** yet. It selects from legal moves using a lightweight heuristic and adjustable randomness. Its displayed Elo is an approximate level label, not a measured engine rating. Before public release, replace this with Stockfish running locally via UCI and calibrate difficulty against real games.

## Run
Install Flutter and Android Studio / Android SDK, then:
```bash
flutter doctor
flutter pub get
flutter run
```
Build a debug APK:
```bash
flutter build apk --debug
```

## Next engineering milestones
1. Verify build and correct any SDK/API issues in the local environment.
2. Integrate Stockfish Android binary and UCI bridge.
3. Implement skill limits / move selection and adapt target strength from recent results.
4. Add proper game-result detection, promotion UI, PGN history and undo logic tests.
5. Add a robust local persistence model and rating calculation tests.
6. Prepare license notices and corresponding Stockfish source/build information for any distributed binary.
