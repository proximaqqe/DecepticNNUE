# Engine and rating design

## Local rating
Use a provisional Elo update for a human vs bot:
`expected = 1 / (1 + 10 ** ((botRating - playerRating) / 400))`
`newRating = round(playerRating + K * (score - expected))`
Start with K=32 and score 1 / 0.5 / 0. The current prototype uses a simplified update; replace it with this formula and unit tests before release.

## Adaptive bot
- Keep a target strength from the player's rating and recent performance.
- Use Stockfish locally and constrain strength through supported UCI options such as Skill Level / UCI_LimitStrength / UCI_Elo where supported by the chosen build.
- Do not assume the engine's nominal Elo maps exactly to human online ratings. Calibrate against a test suite and human play.
- Make the game intentionally learnable: offer hints, takebacks, and post-game explanations as optional training tools.
- Adjust gradually after several games rather than overreacting to one win or loss.

## Offline storage
Persist rating, result history, settings, and PGN locally. Provide export/reset options and no mandatory account.
