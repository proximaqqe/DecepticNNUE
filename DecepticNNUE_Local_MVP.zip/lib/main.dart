import 'dart:math';
import 'package:chess/chess.dart' as chess;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const DecepticApp());

const ink = Color(0xFF0B0D12);
const panel = Color(0xFF151923);
const violet = Color(0xFF9B7BFF);
const mint = Color(0xFF64F4C5);
const pieceGlyphs = <String, String>{
  'K':'♔','Q':'♕','R':'♖','B':'♗','N':'♘','P':'♙',
  'k':'♚','q':'♛','r':'♜','b':'♝','n':'♞','p':'♟',
};

class DecepticApp extends StatelessWidget {
  const DecepticApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'DecepticNNUE',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: ink,
      colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.dark, surface: panel),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  chess.Chess game = chess.Chess();
  int rating = 800;
  int botElo = 800;
  int wins = 0, losses = 0, draws = 0;
  int skill = 3;
  String? selected;
  Set<String> targets = {};
  bool thinking = false;
  bool gameRecorded = false;
  final Random random = Random();

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      rating = p.getInt('rating') ?? 800;
      wins = p.getInt('wins') ?? 0;
      losses = p.getInt('losses') ?? 0;
      draws = p.getInt('draws') ?? 0;
      skill = p.getInt('skill') ?? 3;
      botElo = _eloForSkill(skill);
    });
  }

  int _eloForSkill(int level) => 500 + level * 150;

  Future<void> _saveStats() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('rating', rating);
    await p.setInt('wins', wins);
    await p.setInt('losses', losses);
    await p.setInt('draws', draws);
    await p.setInt('skill', skill);
  }

  String _square(int row, int col) => '${'abcdefgh'[col]}${8-row}';

  String? _pieceAt(String square) {
    final p = game.get(square);
    if (p == null) return null;
    final letter = p.type.name;
    return p.color == chess.WHITE ? letter.toUpperCase() : letter.toLowerCase();
  }

  List<Map<String, dynamic>> _legalMovesFrom(String square) {
    return game.moves({'square': square, 'verbose': true}).cast<Map<String, dynamic>>();
  }

  void _tapSquare(int row, int col) {
    if (thinking || game.game_over || game.turn != chess.WHITE) return;
    final square = _square(row, col);
    final piece = game.get(square);

    if (selected != null && targets.contains(square)) {
      final move = _legalMovesFrom(selected!).firstWhere((m) => m['to'] == square);
      final promotion = move['flags']?.toString().contains('p') == true ? 'q' : 'q';
      final ok = game.move({'from': selected, 'to': square, 'promotion': promotion});
      if (ok) {
        setState(() { selected = null; targets = {}; });
        _afterMove();
        return;
      }
    }

    if (piece != null && piece.color == chess.WHITE) {
      final moves = _legalMovesFrom(square);
      setState(() {
        selected = square;
        targets = moves.map((m) => m['to'] as String).toSet();
      });
    } else {
      setState(() { selected = null; targets = {}; });
    }
  }

  void _afterMove() {
    if (game.game_over) {
      _finishGame();
      return;
    }
    _playBotMove();
  }

  Future<void> _playBotMove() async {
    setState(() => thinking = true);
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (!mounted || game.game_over) return;
    final legal = game.moves({'verbose': true}).cast<Map<String, dynamic>>();
    if (legal.isEmpty) {
      setState(() => thinking = false);
      _finishGame();
      return;
    }

    // Starter adaptive policy: lower levels deliberately choose from a wider
    // candidate pool; higher levels prefer captures and promotions. Replace
    // this policy with Stockfish UCI strength limiting in the engine milestone.
    legal.shuffle(random);
    legal.sort((a, b) => _moveScore(b).compareTo(_moveScore(a)));
    final poolSize = max(1, (legal.length * (1.0 - skill * 0.075)).round());
    final candidates = legal.take(poolSize).toList();
    final chosen = candidates[random.nextInt(candidates.length)];
    game.move({'from': chosen['from'], 'to': chosen['to'], 'promotion': 'q'});
    setState(() => thinking = false);
    if (game.game_over) {
      _finishGame();
    } else {
      setState(() {});
    }
  }

  int _moveScore(Map<String, dynamic> move) {
    var score = random.nextInt(3);
    final captured = move['captured'];
    if (captured != null) {
      const values = {'p':1,'n':3,'b':3,'r':5,'q':9,'k':100};
      score += ((values[captured.toString().toLowerCase()] ?? 1) * skill);
    }
    if (move['promotion'] != null) score += skill * 8;
    return score;
  }

  Future<void> _finishGame() async {
    if (gameRecorded) return;
    gameRecorded = true;
    final playerWon = game.in_checkmate && game.turn == chess.BLACK;
    final isDraw = game.in_draw || game.in_stalemate || game.insufficient_material;
    setState(() {
      if (isDraw) {
        draws++;
      } else if (playerWon) {
        wins++;
        rating += max(8, 24 - ((rating - botElo).abs() ~/ 80));
      } else {
        losses++;
        rating = max(100, rating - max(6, 20 - ((rating - botElo).abs() ~/ 100)));
      }
    });
    await _saveStats();
    if (!mounted) return;
    final result = isDraw ? 'Draw' : playerWon ? 'You won!' : 'Bot won';
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: panel,
        title: Text(result),
        content: Text('Local rating: $rating\\nRecord: $wins wins · $draws draws · $losses losses'),
        actions: [TextButton(onPressed: () { Navigator.pop(context); _newGame(); }, child: const Text('PLAY AGAIN'))],
      ),
    );
  }

  void _newGame() {
    setState(() {
      game = chess.Chess();
      selected = null;
      targets = {};
      thinking = false;
      gameRecorded = false;
      botElo = _eloForSkill(skill);
    });
  }

  String _status() {
    if (game.game_over) return 'Game finished';
    if (thinking) return 'Deceptic is thinking…';
    if (game.in_check) return 'Check! Your move';
    return 'Your turn · White';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(color: violet.withValues(alpha: .15), borderRadius: BorderRadius.circular(10), border: Border.all(color: violet.withValues(alpha: .6))), child: const Icon(Icons.bolt, color: violet)),
          const SizedBox(width: 9),
          const Text('DECEPTIC', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          const SizedBox(width: 5),
          const Text('NNUE', style: TextStyle(color: mint, fontWeight: FontWeight.w900)),
        ]),
        actions: [IconButton(onPressed: _newGame, icon: const Icon(Icons.refresh), tooltip: 'New game')],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 22),
          children: [
            Row(children: [
              Expanded(child: _stat('LOCAL RATING', '$rating', Icons.trending_up)),
              const SizedBox(width: 10),
              Expanded(child: _stat('BOT LEVEL', '$skill / 10', Icons.psychology)),
            ]),
            const SizedBox(height: 14),
            Card(child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(children: [
                const CircleAvatar(backgroundColor: Color(0xFF28233E), child: Icon(Icons.smart_toy_outlined, color: violet)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Deceptic adaptive bot', style: TextStyle(fontWeight: FontWeight.w800)),
                  Text('Estimated strength $botElo Elo · offline', style: const TextStyle(color: Colors.white60, fontSize: 12)),
                ])),
                Container(width: 8, height: 8, decoration: const BoxDecoration(color: mint, shape: BoxShape.circle)),
              ]),
            )),
            const SizedBox(height: 12),
            AspectRatio(
              aspectRatio: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  itemCount: 64,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
                  itemBuilder: (context, index) {
                    final row = index ~/ 8, col = index % 8;
                    final sq = _square(row, col);
                    final light = (row + col).isEven;
                    final isSelected = selected == sq;
                    final isTarget = targets.contains(sq);
                    final piece = _pieceAt(sq);
                    return GestureDetector(
                      onTap: () => _tapSquare(row, col),
                      child: Container(
                        decoration: BoxDecoration(
                          color: isSelected ? const Color(0xFFB4A0FF) : light ? const Color(0xFFDADDE8) : const Color(0xFF59617C),
                          border: isTarget ? Border.all(color: mint, width: 3) : null,
                        ),
                        alignment: Alignment.center,
                        child: Stack(alignment: Alignment.center, children: [
                          if (piece != null) Text(pieceGlyphs[piece] ?? '', style: TextStyle(fontSize: 32, height: 1, color: piece == piece.toUpperCase() ? const Color(0xFFF9F7FF) : const Color(0xFF20232D), shadows: const [Shadow(color: Colors.black45, blurRadius: 2, offset: Offset(1, 2))])),
                          if (isTarget && piece == null) Container(width: 9, height: 9, decoration: BoxDecoration(color: mint.withValues(alpha: .9), shape: BoxShape.circle)),
                        ]),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Icon(thinking ? Icons.hourglass_top : Icons.circle, size: 9, color: mint),
              const SizedBox(width: 7),
              Expanded(child: Text(_status(), style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600))),
              Text('${game.move_number - 1} moves', style: const TextStyle(color: Colors.white38, fontSize: 12)),
            ]),
            const SizedBox(height: 12),
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [const Icon(Icons.tune, color: violet), const SizedBox(width: 8), const Text('Adaptive difficulty', style: TextStyle(fontWeight: FontWeight.w800))]),
                Slider(value: skill.toDouble(), min: 1, max: 10, divisions: 9, activeColor: violet, label: 'Level $skill', onChanged: (v) { setState(() { skill = v.round(); botElo = _eloForSkill(skill); }); _saveStats(); }),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
                  Text('Relaxed', style: TextStyle(color: Colors.white54, fontSize: 12)),
                  Text('Challenging', style: TextStyle(color: Colors.white54, fontSize: 12)),
                ]),
              ]),
            )),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _newGame, icon: const Icon(Icons.play_arrow), label: const Text('NEW GAME'), style: FilledButton.styleFrom(backgroundColor: violet, foregroundColor: ink, padding: const EdgeInsets.symmetric(vertical: 14)))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: () { if (game.history.isNotEmpty && !thinking) { setState(() { game.undo(); if (game.turn == chess.BLACK && game.history.isNotEmpty) game.undo(); selected = null; targets = {}; gameRecorded = false; }); } }, icon: const Icon(Icons.undo), label: const Text('UNDO'), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)))),
            ]),
            const SizedBox(height: 12),
            Text('Record: $wins wins · $draws draws · $losses losses', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 6),
            const Text('Offline alpha · Adaptive move selection prototype. Stockfish integration is the next milestone.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white30, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value, IconData icon) => Card(child: Padding(
    padding: const EdgeInsets.all(13),
    child: Row(children: [
      Icon(icon, color: mint, size: 22),
      const SizedBox(width: 9),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 9, letterSpacing: 1, fontWeight: FontWeight.w800)),
        const SizedBox(height: 3),
        Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
      ])),
    ]),
  ));
}
